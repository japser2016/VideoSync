# VideoSync
A low latency video syncing program to allow for watching videos with friends.

Written in C

Written for final assignment in CS112 Networking at Tufts University.

Written by
gabman15
and
jasper2016
